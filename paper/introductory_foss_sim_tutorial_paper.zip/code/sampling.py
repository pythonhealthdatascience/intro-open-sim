import numpy as np

ng = np.random.default_rng(42)
samples = rng.uniform(low=10, high=40, size=1_000_000)
